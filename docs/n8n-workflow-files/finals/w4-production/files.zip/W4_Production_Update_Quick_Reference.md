# W4 Production Update - Quick Reference Checklist

## Enabled Nodes Requiring Updates

| # | Node Name | Priority | Type | Updates Required |
|---|-----------|----------|------|------------------|
| 1 | Config (W4) — SANDBOX | 🔴 CRITICAL | Code | • API URL: `api.sandbox.lulu.com` → `api.lulu.com`<br>• Replace clientKey<br>• Replace clientSecret<br>• Update node name<br>• Update comments |
| 2 | Validate Interior (SANDBOX) | 🟡 HIGH | HTTP Request | • Fallback URL: `api.sandbox.lulu.com` → `api.lulu.com`<br>• Update node name |
| 3 | Validate Cover (SANDBOX) | 🟡 HIGH | HTTP Request | • Fallback URL: `api.sandbox.lulu.com` → `api.lulu.com`<br>• Update node name |
| 4 | Lulu SANDBOX: Get Token (Retry) | 🟡 HIGH | Code | • API URL: `api.sandbox.lulu.com` → `api.lulu.com`<br>• Update node name |
| 5 | Submit Lulu Print Job (SANDBOX - BEARER, Retry) | 🔴 CRITICAL | Code | • API URL: `api.sandbox.lulu.com` → `api.lulu.com`<br>• Update node name<br>• Review test parameters |
| 6 | Extract Lulu Access Token (SANDBOX) | 🟢 MEDIUM | Code | • Update node name only |
| 7 | Simulate Merge | 🟢 MEDIUM | Code | • Review if needed in production<br>• Update API URLs if used |
| 8 | Sticky: Switch SANDBOX ↔ PRODUCTION | 🟢 LOW | Note | • Update note text<br>• Add production warnings |

---

## Node IDs for Quick Reference

```
Config (W4) — SANDBOX:                                  774138a4-edad-4d79-9e34-0db84743e639
Validate Interior (SANDBOX):                            5dec046b-3b89-496c-a9d1-1bba806c419a
Validate Cover (SANDBOX):                               474aa7b8-024d-4f25-8ab1-4d8627442f32
Lulu SANDBOX: Get Token (Retry):                        35ab60f4-f2e4-4dae-87a6-b8c3ec1488ec
Submit Lulu Print Job (SANDBOX - BEARER, Retry):       8e403c43-700a-4fef-a7a9-55308c9d2041
Extract Lulu Access Token (SANDBOX):                    b19043a5-aa9f-4961-a003-ea367729e857
Simulate Merge:                                         fe459131-1cf4-4d5f-b221-2ccbaaecc7f8
Sticky: Switch SANDBOX ↔ PRODUCTION:                    52f705fb-cbbc-41cc-8a12-8569bbae916a
```

---

## Disabled Production Nodes (Review Needed)

| Node Name | Status | Node ID |
|-----------|--------|---------|
| Submit Lulu Print Job (PRODUCTION - BASIC) | DISABLED | 5486fefa-6ee1-4eb0-b402-26d8e60c63eb |
| Lulu PRODUCTION: Get Token | DISABLED | 7daca0a3-2bfd-4732-a6a0-c713184d6d19 |
| Extract Lulu Access Token (PRODUCTION) | DISABLED | 60ad6326-3f85-43dc-b1b2-c3bb81fca6e5 |
| Submit Lulu Print Job (PRODUCTION - BEARER) | DISABLED | ebb75f86-072e-4549-b33f-febe2f961cc1 |
| Config (W4) — PRODUCTION | ENABLED* | bb690fbc-9f0b-46fb-b2c2-88ee3dda37e3 |
| Lulu PRODUCTION: Get Token (Retry) | DISABLED | 43e85dab-0913-41ff-a49d-2f517ff239c0 |
| Submit Lulu Print Job (PRODUCTION - BEARER, Retry) | DISABLED | 51655c31-a414-40aa-9268-5d669080be11 |

*Note: Config (W4) — PRODUCTION is enabled but contains placeholder credentials

---

## Current vs Target Configuration

| Configuration Item | Current (Sandbox) | Target (Production) |
|-------------------|-------------------|---------------------|
| API Base URL | `https://api.sandbox.lulu.com` | `https://api.lulu.com` |
| Client Key | `081227f0-b9ad-454f-87cd-db4b264c286b` | **[NEED PRODUCTION KEY]** |
| Client Secret | `KhGxFLNuRVw3MwlidTmx...` | **[NEED PRODUCTION SECRET]** |

---

## Update Progress Tracker

### Pre-Update
- [ ] Backup current workflow
- [ ] Obtain production credentials
- [ ] Review disabled production nodes
- [ ] Create test plan
- [ ] Document rollback procedure

### Critical Updates (Must Complete)
- [ ] Node 1: Config (W4) — SANDBOX
- [ ] Node 5: Submit Lulu Print Job (SANDBOX - BEARER, Retry)

### High Priority Updates
- [ ] Node 2: Validate Interior (SANDBOX)
- [ ] Node 3: Validate Cover (SANDBOX)
- [ ] Node 4: Lulu SANDBOX: Get Token (Retry)

### Medium/Low Priority Updates
- [ ] Node 6: Extract Lulu Access Token (SANDBOX)
- [ ] Node 7: Simulate Merge (if needed)
- [ ] Node 8: Sticky Note

### Post-Update Testing
- [ ] Test token acquisition
- [ ] Test PDF validation
- [ ] Test print job submission (with test order)
- [ ] Verify Lulu dashboard
- [ ] Check Supabase tracking
- [ ] Monitor first production order

---

## Search & Replace Patterns

For quick text replacement when editing nodes:

1. **API URL:**
   - Find: `https://api.sandbox.lulu.com`
   - Replace: `https://api.lulu.com`

2. **Node Names:**
   - Find: `SANDBOX`
   - Replace: `PRODUCTION`

3. **Comments:**
   - Find: `/* SANDBOX CONFIG */`
   - Replace: `/* PRODUCTION CONFIG */`

4. **Credentials (Config Node):**
   - Find: `clientKey: '081227f0-b9ad-454f-87cd-db4b264c286b'`
   - Replace: `clientKey: '[YOUR_PRODUCTION_KEY]'`
   
   - Find: `clientSecret: 'KhGxFLNuRVw3MwlidTmxkvGaH8E2OS3E'`
   - Replace: `clientSecret: '[YOUR_PRODUCTION_SECRET]'`

---

## Testing Checklist

After each update:

- [ ] Node saved successfully
- [ ] No syntax errors in code nodes
- [ ] Workflow activates without errors
- [ ] Test execution completed
- [ ] Lulu API responds correctly
- [ ] Order appears in Lulu dashboard
- [ ] Supabase updates correctly
- [ ] No error notifications

---

## Quick Links

- **Full Documentation:** W4_Sandbox_to_Production_Update_Plan.md
- **Workflow Name:** WORKING VERSION - LHB - 4 - PRINT FULFILLMENT
- **Backup Recommended Name:** LHB - 4 - PRINT FULFILLMENT - SANDBOX VERSION

---

**Last Updated:** November 13, 2025
