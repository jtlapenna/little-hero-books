# W4 Workflow: Sandbox to Production Update Plan

**Workflow:** WORKING VERSION - LHB - 4 - PRINT FULFILLMENT  
**Current State:** Configured for Lulu Sandbox API  
**Target State:** Configured for Lulu Production API  
**Date:** November 13, 2025

---

## Executive Summary

Your W4 workflow currently has **8 enabled nodes** that reference sandbox configurations and need to be updated for production use. Additionally, there are **8 disabled production placeholder nodes** that may need to be reviewed and potentially enabled/updated.

The primary changes required are:
1. **API Base URL:** Change from `https://api.sandbox.lulu.com` to `https://api.lulu.com`
2. **Lulu Credentials:** Replace sandbox client key/secret with production credentials
3. **Node Names:** Update node names to reflect production environment
4. **Validation URLs:** Update fallback URLs in validation nodes

---

## Current Configuration Status

### Sandbox Credentials (Currently Active)
- **API Base:** `https://api.sandbox.lulu.com`
- **Client Key:** `081227f0-b9ad-454f-87cd-db4b264c286b`
- **Client Secret:** `KhGxFLNuRVw3MwlidTmx...` (partial shown)

### Production Credentials (Placeholder Found)
- **API Base:** `https://api.lulu.com`
- **Client Key:** `REPLACE_WITH_LULU_CLIENT_KEY` ⚠️ **NEEDS ACTUAL KEY**
- **Client Secret:** `REPLACE_WITH_LULU_CL...` ⚠️ **NEEDS ACTUAL SECRET**

---

## Nodes Requiring Updates (Enabled)

### 1. Config (W4) — SANDBOX
**Node ID:** `774138a4-edad-4d79-9e34-0db84743e639`  
**Type:** Code Node  
**Priority:** 🔴 **CRITICAL** - This is the main configuration node

**Required Changes:**
- [ ] Update node name: `Config (W4) — SANDBOX` → `Config (W4) — PRODUCTION`
- [ ] Change API base URL: `https://api.sandbox.lulu.com` → `https://api.lulu.com`
- [ ] Replace Lulu client key with production key
- [ ] Replace Lulu client secret with production secret
- [ ] Update comment from `/* SANDBOX CONFIG */` to `/* PRODUCTION CONFIG */`

**Current Code Location:** Lines containing:
```javascript
lulu: {
  apiBase: 'https://api.sandbox.lulu.com',
  clientKey: '081227f0-b9ad-454f-87cd-db4b264c286b',
  clientSecret: 'KhGxFLNuRVw3MwlidTmxkvGaH8E2OS3E',
  basicAuth: null
}
```

**Notes:** 
- This config object is used throughout the workflow
- The `basicAuth` value is auto-generated from the credentials
- Ensure production credentials are valid before updating

---

### 2. Validate Interior (SANDBOX)
**Node ID:** `5dec046b-3b89-496c-a9d1-1bba806c419a`  
**Type:** HTTP Request Node  
**Priority:** 🟡 **HIGH**

**Required Changes:**
- [ ] Update node name: `Validate Interior (SANDBOX)` → `Validate Interior (PRODUCTION)`
- [ ] Update fallback URL in expression:
  - Current: `|| "https://api.sandbox.lulu.com"`
  - Should be: `|| "https://api.lulu.com"`

**Current URL Expression:**
```
={{$node["Validate & Normalize W4 Input"].json.CONFIG.lulu.apiBase || $json.CONFIG.lulu.apiBase || "https://api.sandbox.lulu.com"}}/validate-interior/
```

**Notes:**
- Primary URL comes from CONFIG, but fallback needs updating
- Tests interior PDF against Lulu's specifications

---

### 3. Validate Cover (SANDBOX)
**Node ID:** `474aa7b8-024d-4f25-8ab1-4d8627442f32`  
**Type:** HTTP Request Node  
**Priority:** 🟡 **HIGH**

**Required Changes:**
- [ ] Update node name: `Validate Cover (SANDBOX)` → `Validate Cover (PRODUCTION)`
- [ ] Update fallback URL in expression:
  - Current: `|| "https://api.sandbox.lulu.com"`
  - Should be: `|| "https://api.lulu.com"`

**Current URL Expression:**
```
={{$node["Validate & Normalize W4 Input"].json.CONFIG.lulu.apiBase || $json.CONFIG.lulu.apiBase || "https://api.sandbox.lulu.com"}}/validate-cover/
```

**Notes:**
- Similar to Validate Interior node
- Tests cover PDF against Lulu's specifications

---

### 4. Lulu SANDBOX: Get Token (Retry)
**Node ID:** `35ab60f4-f2e4-4dae-87a6-b8c3ec1488ec`  
**Type:** Code Node  
**Priority:** 🟡 **HIGH**

**Required Changes:**
- [ ] Update node name: `Lulu SANDBOX: Get Token (Retry)` → `Lulu PRODUCTION: Get Token (Retry)`
- [ ] Change hardcoded API URL from `https://api.sandbox.lulu.com` to `https://api.lulu.com`
- [ ] Verify retry logic works with production API

**Notes:**
- This is the retry mechanism for getting OAuth tokens
- Contains hardcoded sandbox URL that needs updating
- Part of the error recovery flow

---

### 5. Submit Lulu Print Job (SANDBOX - BEARER, Retry)
**Node ID:** `8e403c43-700a-4fef-a7a9-55308c9d2041`  
**Type:** Code Node  
**Priority:** 🔴 **CRITICAL** - This submits actual print jobs

**Required Changes:**
- [ ] Update node name: `Submit Lulu Print Job (SANDBOX - BEARER, Retry)` → `Submit Lulu Print Job (PRODUCTION - BEARER, Retry)`
- [ ] Change hardcoded API URL from `https://api.sandbox.lulu.com` to `https://api.lulu.com`
- [ ] Review any sandbox-specific test parameters

**Notes:**
- This is the retry version of the print job submission
- CRITICAL: This will create real print orders with production credentials
- Test thoroughly in sandbox before switching to production

---

### 6. Extract Lulu Access Token (SANDBOX)
**Node ID:** `b19043a5-aa9f-4961-a003-ea367729e857`  
**Type:** Code Node  
**Priority:** 🟢 **MEDIUM**

**Required Changes:**
- [ ] Update node name: `Extract Lulu Access Token (SANDBOX)` → `Extract Lulu Access Token (PRODUCTION)`

**Notes:**
- This node extracts the token from the OAuth response
- Logic should be environment-agnostic, only name needs updating

---

### 7. Simulate Merge
**Node ID:** `fe459131-1cf4-4d5f-b221-2ccbaaecc7f8`  
**Type:** Code Node  
**Priority:** 🟢 **MEDIUM** - Testing/Development node

**Required Changes:**
- [ ] Review if this node is used in production flow
- [ ] If used: Update API URLs and credentials references
- [ ] If not used: Consider disabling for production

**Notes:**
- Appears to be a simulation/testing node
- Contains sandbox API references
- May only be needed for development

---

### 8. Sticky: Switch SANDBOX ↔ PRODUCTION
**Node ID:** `52f705fb-cbbc-41cc-8a12-8569bbae916a`  
**Type:** Sticky Note  
**Priority:** 🟢 **LOW** - Documentation only

**Required Changes:**
- [ ] Update note text to reflect production configuration
- [ ] Add warning about production environment consequences

**Notes:**
- This is a visual note/reminder in the workflow
- Should be updated to clearly indicate production mode
- Consider adding additional warnings about real orders

---

## Disabled Production Nodes (To Review)

These nodes were created as production placeholders but are currently disabled. They may need to be enabled and/or updated once the main nodes are switched to production:

### 9. Submit Lulu Print Job (PRODUCTION - BASIC)
**Node ID:** `5486fefa-6ee1-4eb0-b402-26d8e60c63eb`  
**Status:** DISABLED  
**Notes:** May be an older authentication method (Basic vs Bearer)

### 10. Lulu PRODUCTION: Get Token
**Node ID:** `7daca0a3-2bfd-4732-a6a0-c713184d6d19`  
**Status:** DISABLED  
**Notes:** Non-retry version of token acquisition

### 11. Extract Lulu Access Token (PRODUCTION)
**Node ID:** `60ad6326-3f85-43dc-b1b2-c3bb81fca6e5`  
**Status:** DISABLED  
**Notes:** Production version of token extraction

### 12. Submit Lulu Print Job (PRODUCTION - BEARER)
**Node ID:** `ebb75f86-072e-4549-b33f-febe2f961cc1`  
**Status:** DISABLED  
**Notes:** Non-retry version of print job submission

### 13. Config (W4) — PRODUCTION
**Node ID:** `bb690fbc-9f0b-46fb-b2c2-88ee3dda37e3`  
**Status:** ENABLED (but not connected in flow?)  
**Notes:** Contains placeholder credentials that need real values

### 14. Lulu PRODUCTION: Get Token (Retry)
**Node ID:** `43e85dab-0913-41ff-a49d-2f517ff239c0`  
**Status:** DISABLED  
**Notes:** Production version currently disabled while sandbox retry is enabled

### 15. Submit Lulu Print Job (PRODUCTION - BEARER, Retry)
**Node ID:** `51655c31-a414-40aa-9268-5d669080be11`  
**Status:** DISABLED  
**Notes:** Production version currently disabled while sandbox retry is enabled

---

## Additional Nodes with Lulu References (No Changes Needed)

These enabled nodes reference Lulu but don't need configuration updates:

- **Build Lulu Print Job Payload** - Environment-agnostic payload builder
- **Process Lulu Response** - Environment-agnostic response processor
- **Guard Lulu Submit** - Logic node (config-driven)
- **Decide Lulu Source URLs (NO PROXY)** - Uses config from upstream
- **Status Banner (Env & Submit Path)** - Displays current environment
- **Build 4-Manifest JSON** - Data structure builder
- **Hydrate Order Details** - Supabase data retrieval

---

## Pre-Update Checklist

Before making any changes:

- [ ] **Obtain Production Credentials:** Get actual Lulu production API client key and secret
- [ ] **Backup Current Workflow:** Save current working version with clear sandbox naming
- [ ] **Document Differences:** Note any workflow logic differences between sandbox/production nodes
- [ ] **Test Plan:** Create comprehensive test plan for production verification
- [ ] **Rollback Plan:** Document how to quickly revert to sandbox if issues occur
- [ ] **Rate Limits:** Verify production API rate limits and quotas
- [ ] **Cost Review:** Understand production API costs and print job charges

---

## Update Sequence (Recommended)

### Phase 1: Preparation
1. Save current workflow as `LHB - 4 - PRINT FULFILLMENT - SANDBOX VERSION`
2. Obtain production Lulu API credentials
3. Review disabled production nodes for any missing features

### Phase 2: Critical Configuration
1. Update **Config (W4) — SANDBOX** node (#1) - Most critical
2. Test config change in isolation

### Phase 3: API Interaction Nodes
3. Update **Validate Interior (SANDBOX)** (#2)
4. Update **Validate Cover (SANDBOX)** (#3)
5. Update **Lulu SANDBOX: Get Token (Retry)** (#4)

### Phase 4: Print Job Submission
6. Update **Submit Lulu Print Job (SANDBOX - BEARER, Retry)** (#5) - CRITICAL
7. Update **Extract Lulu Access Token (SANDBOX)** (#6)

### Phase 5: Supporting Nodes
8. Review and update **Simulate Merge** (#7) if needed
9. Update **Sticky Note** (#8) for documentation

### Phase 6: Testing
10. Run end-to-end test with test order
11. Verify Lulu dashboard shows order correctly
12. Monitor first production order closely

---

## Risk Assessment

### 🔴 **High Risk - Immediate Impact**
- **Config Node:** Incorrect credentials = entire workflow fails
- **Submit Print Job Node:** Errors here create real, potentially incorrect orders

### 🟡 **Medium Risk - Quality Impact**
- **Validation Nodes:** May submit invalid PDFs to production
- **Token Retry Logic:** Could cause authentication failures

### 🟢 **Low Risk - Cosmetic**
- **Node Names:** Only affect workflow readability
- **Sticky Notes:** Documentation only

---

## Post-Update Verification

After updating each node:

- [ ] Save workflow incrementally
- [ ] Test with a single test order
- [ ] Verify Lulu dashboard shows order
- [ ] Check Supabase order tracking updates
- [ ] Monitor for error notifications
- [ ] Review PDF quality in production
- [ ] Confirm shipping label generation

---

## Emergency Contacts & Resources

- **Lulu API Documentation:** https://developers.lulu.com/
- **Lulu Support:** (Add production support contact)
- **Lulu Production Dashboard:** (Add URL)
- **Workflow Backup Location:** (Add path to backups)

---

## Notes

- The workflow appears to have a dual-config setup with both sandbox and production config nodes present
- Some disabled production nodes may be outdated based on workflow evolution since their creation
- The retry logic nodes appear to be the actively used submission path
- Consider implementing a feature flag or environment variable for easier sandbox/production switching in the future

---

**Document Version:** 1.0  
**Last Updated:** November 13, 2025  
**Next Review:** After production deployment
