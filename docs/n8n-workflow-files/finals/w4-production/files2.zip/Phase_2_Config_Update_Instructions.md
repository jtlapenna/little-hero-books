# Phase 2: Update Config Node - Step-by-Step Instructions

## Node to Update: Config (W4) — SANDBOX

**Node ID:** `774138a4-edad-4d79-9e34-0db84743e639`

---

## Instructions

### 1. Open the Config Node in n8n
- Navigate to your workflow in n8n
- Find the node named **"Config (W4) — SANDBOX"**
- Double-click to open it

### 2. Update Node Name
- At the top of the node editor, change the name from:
  - **FROM:** `Config (W4) — SANDBOX`
  - **TO:** `Config (W4) — PRODUCTION`

### 3. Update the Code

In the code editor, make these **4 specific changes**:

#### Change #1: Update Comment (Line 3)
**FROM:**
```javascript
/* SANDBOX CONFIG */
```

**TO:**
```javascript
/* PRODUCTION CONFIG */
```

#### Change #2: Update API Base URL (Line 10)
**FROM:**
```javascript
    apiBase: 'https://api.sandbox.lulu.com',
```

**TO:**
```javascript
    apiBase: 'https://api.lulu.com',
```

#### Change #3: Update Client Key (Line 11)
**FROM:**
```javascript
    clientKey: '081227f0-b9ad-454f-87cd-db4b264c286b',
```

**TO:**
```javascript
    clientKey: '9b388aaa-f0c9-448d-b3d1-8561a8cf2094',
```

#### Change #4: Update Client Secret (Line 12)
**FROM:**
```javascript
    clientSecret: 'KhGxFLNuRVw3MwlidTmxkvGaH8E2OS3E',
```

**TO:**
```javascript
    clientSecret: '3fsYZ7GbbXvdQhsOSxstzIbqdbdJMMtS',
```

---

## Alternative: Copy/Paste Entire Code

If you prefer, you can **replace the entire code** with the production version.

The complete updated code is available in: `Config_Node_PRODUCTION_Code.js`

---

## Verification Checklist

After making changes, verify:

- [ ] Node name shows "PRODUCTION" not "SANDBOX"
- [ ] Comment says `/* PRODUCTION CONFIG */`
- [ ] API URL is `https://api.lulu.com` (no "sandbox")
- [ ] Client Key is `9b388aaa-f0c9-448d-b3d1-8561a8cf2094`
- [ ] Client Secret is `3fsYZ7GbbXvdQhsOSxstzIbqdbdJMMtS`
- [ ] No syntax errors (n8n will show red if there are errors)

---

## Save the Node

1. Click **"Execute Node"** to test (optional but recommended)
2. Click **outside the node** or press **ESC** to close
3. **Save your workflow** (Ctrl/Cmd + S)

---

## What This Changes

This config node is used by **ALL** downstream nodes in the workflow. By updating it, you've switched:

✅ Lulu API calls from sandbox → production
✅ Authentication credentials from test → live
✅ All API interactions will now use production environment

---

## ⚠️ CRITICAL WARNING

**This node is now configured for PRODUCTION.**

Any workflow executions from this point forward will:
- Use REAL Lulu production API
- Create REAL print orders
- Incur REAL costs
- Ship REAL products

**Do not execute this workflow until all other nodes are updated and tested!**

---

## Next Steps

After completing this update, we'll proceed to **Phase 3** to update the API interaction nodes (validation, token acquisition).

Let me know when you've completed this step!
