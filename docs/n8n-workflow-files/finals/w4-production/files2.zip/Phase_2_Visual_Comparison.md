# Phase 2: Config Node Changes - Visual Comparison

## Summary of Changes

| Item | Current (Sandbox) | Updated (Production) |
|------|-------------------|---------------------|
| **Node Name** | Config (W4) — SANDBOX | Config (W4) — PRODUCTION |
| **Comment** | /* SANDBOX CONFIG */ | /* PRODUCTION CONFIG */ |
| **API Base** | https://api.sandbox.lulu.com | https://api.lulu.com |
| **Client Key** | 081227f0-b9ad-454f-87cd-db4b264c286b | 9b388aaa-f0c9-448d-b3d1-8561a8cf2094 |
| **Client Secret** | KhGxFLNuRVw3Mwlid... | 3fsYZ7GbbXvdQhsOS... |

---

## Line-by-Line Comparison

```diff
  // Centralized configuration & secrets (hardcoded per request)
  // TODO: USE N8N CREDENTIALS for tokens/keys in production
- /* SANDBOX CONFIG */
+ /* PRODUCTION CONFIG */
  const CONFIG = {
    pdfMonkey: {
      token: '2zpxHdmsse2ECXgVVtVR',
      // interior template (expects pages_html)
      templateId: '5539DDB4-EC78-4AE9-A3FB-DB1E7F8DD172'
    },
    lulu: {
-     apiBase: 'https://api.sandbox.lulu.com',
+     apiBase: 'https://api.lulu.com',
-     clientKey: '081227f0-b9ad-454f-87cd-db4b264c286b',
+     clientKey: '9b388aaa-f0c9-448d-b3d1-8561a8cf2094',
-     clientSecret: 'KhGxFLNuRVw3MwlidTmxkvGaH8E2OS3E',
+     clientSecret: '3fsYZ7GbbXvdQhsOSxstzIbqdbdJMMtS',
      basicAuth: null
    },
    supabase: {
      projectUrl: 'https://mdnthwpcnphjnnblbvxk.supabase.co',
      serviceRoleKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
    },
    r2: {
      bucket: 'little-hero-orders',
      endpointHost: '3daae940fcb6fc5b8bbd9bb8fcc62854.r2.cloudflarestorage.com',
      region: 'auto',
      accessKeyId: '320e3b8228c5ff7bd2395043886f03d3',
      secretAccessKey: 'a1ba025ddbe2d8ef7032d2d6635dce3b6fbc4bdbf9c19c68d0b0bd566c989572'
    },
    defaults: {
      debug: false,
      testMode: false,
      // 🔑 Lulu POD package (8.5x8.5, premium-color, perfect-bound, 80# text, matte)
      podPackageId: '0850X0850FCPRESS080CW444MXX',  // Saddle-stitch for 15 pages
      trimIn: {
        w: 8.5, h: 8.5,
        assetBase: 'https://admin.littleherolabs.com/api/assets/',
        podPackageId: null // kept null; top-level defaults.podPackageId is source of truth
      },
      bleedIn: { w: 8.75, h: 8.75 },
      print: {
        color: 'premium-color',
        stock: '80#-text',
        binding: 'saddle-stitch',
        coverFinish: 'matte'
      },
      quantity: 1,
      shippingLevel: 'STANDARD'
    }
  };
  
  // --- derive basicAuth from client credentials (computed here to avoid expression quirks) ---
  try {
    const k = CONFIG?.lulu?.clientKey || '';
    const s = CONFIG?.lulu?.clientSecret || '';
    const b = Buffer.from(`${k}:${s}`).toString('base64');
    if (!CONFIG.lulu) CONFIG.lulu = {};
    CONFIG.lulu.basicAuth = 'Basic ' + b;
  } catch (e) {
    // leave basicAuth as-is if Buffer not available (should be available in Code nodes)
  }
  
  
  return [{ json: { CONFIG } }];
```

---

## Quick Copy/Paste Values

If manually editing, here are the exact values to paste:

### Production API Base URL:
```
https://api.lulu.com
```

### Production Client Key:
```
9b388aaa-f0c9-448d-b3d1-8561a8cf2094
```

### Production Client Secret:
```
3fsYZ7GbbXvdQhsOSxstzIbqdbdJMMtS
```

---

## Important Notes

1. **Only 4 lines change** - the rest of the config remains identical
2. **pdfMonkey, Supabase, R2, and defaults** sections stay the same
3. The `basicAuth` value is **auto-generated** from the credentials (no manual update needed)
4. All other nodes read from this CONFIG object, so this change affects the entire workflow

---

## Double-Check These Specific Characters

These credentials use specific characters that are easy to mistype:

**Client Key:**
- Starts with: `9b388`
- Contains dashes: `-f0c9-`
- Ends with: `cf2094`

**Client Secret:**
- Starts with: `3fsYZ7`
- Mix of upper/lowercase: `GbbXvdQhs`
- Ends with: `JMMtS`

---

**After making these changes, proceed to the next phase to update the API interaction nodes.**
