// Centralized configuration & secrets (hardcoded per request)
// TODO: USE N8N CREDENTIALS for tokens/keys in production
/* PRODUCTION CONFIG */
const CONFIG = {
  pdfMonkey: {
    token: '2zpxHdmsse2ECXgVVtVR',
    // interior template (expects pages_html)
    templateId: '5539DDB4-EC78-4AE9-A3FB-DB1E7F8DD172'
  },
  lulu: {
    apiBase: 'https://api.lulu.com',
    clientKey: '9b388aaa-f0c9-448d-b3d1-8561a8cf2094',
    clientSecret: '3fsYZ7GbbXvdQhsOSxstzIbqdbdJMMtS',
    basicAuth: null
  },
  supabase: {
    projectUrl: 'https://mdnthwpcnphjnnblbvxk.supabase.co',
    serviceRoleKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1kbnRod3BjbnBoam5uYmxidnhrIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MDUwMDc4MCwiZXhwIjoyMDc2MDc2NzgwfQ.wNVQ3U2nWTGu8VsuXKasWOCxVhpca5x42wSapQDinGs'
  },
  r2: {
    bucket: 'little-hero-orders',
    endpointHost: '3daae940fcb6fc5b8bbd9bb8fcc62854.r2.cloudflarestorage.com',
    region: 'auto',
    accessKeyId: '320e3b8228c5ff7bd2395043886f03d3',
    secretAccessKey: 'a1ba025ddbe2d8ef7032d2d6635dce3b6fbc4bdbf9c19c68d0b0bd566c989572'
  },
  defaults: {
    debug: false,
    testMode: false,
    // 🔑 Lulu POD package (8.5x8.5, premium-color, perfect-bound, 80# text, matte)
    podPackageId: '0850X0850FCPRESS080CW444MXX',  // Saddle-stitch for 15 pages
    trimIn: {
      w: 8.5, h: 8.5,
      assetBase: 'https://admin.littleherolabs.com/api/assets/',
      podPackageId: null // kept null; top-level defaults.podPackageId is source of truth
    },
    bleedIn: { w: 8.75, h: 8.75 },
    print: {
      color: 'premium-color',
      stock: '80#-text',
      binding: 'saddle-stitch',
      coverFinish: 'matte'
    },
    quantity: 1,
    shippingLevel: 'STANDARD'
  }
};

// --- derive basicAuth from client credentials (computed here to avoid expression quirks) ---
try {
  const k = CONFIG?.lulu?.clientKey || '';
  const s = CONFIG?.lulu?.clientSecret || '';
  const b = Buffer.from(`${k}:${s}`).toString('base64');
  if (!CONFIG.lulu) CONFIG.lulu = {};
  CONFIG.lulu.basicAuth = 'Basic ' + b;
} catch (e) {
  // leave basicAuth as-is if Buffer not available (should be available in Code nodes)
}


return [{ json: { CONFIG } }];
